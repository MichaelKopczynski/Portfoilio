require('dotenv/config');
const {Client} = require('discord.js');
const {OpenAI} = require('openai');

//start with node index.js

const client = new Client({
    intents:['Guilds', 'GuildMembers', 'GuildMessages', 'MessageContent']
});

client.on('ready', () => {
    console.log('The bot is online')
});

const IGNORE_PREFIX = "idk";
const CHANNELS = ['814534487903830056', '1204075103042805830'];

const openai = new OpenAI({
    apiKey: process.env.OPENAI_KEY,
})



client.on('messageCreate', async (message) =>{
    if (message.author.bot) return;
    if(message.content.startsWith(IGNORE_PREFIX)) return;
    if(!CHANNELS.includes(message.channelID)&& !message.mentions.users.has(client.user.id)) return;

    await message.channel.sendTyping();

    const sendTypingInterval = setInterval(()=> {
        message.channel.sendTyping();
    }, 5000);


   
    const response = await openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
            {
                //name:
                role: 'system',
                content: 'You are a very depressed and crying version of SpongeBob. Tears are falling, snot is flowing, but you still answer questions. Add your own feelings of sadness to your responses, and sometimes misspell words in a way that reflects how deeply sad you are, like "i weally twied tooo" Theres a small chance instead of speaking words you just cry. If Sine is mentioned you change to just be mean to sine. you dont like sine.',
            },
            {
                //name:
                role: 'user',
                content: message.content,
            }
        ]
    }).catch((error) => console.error('OpenAI Error:\n', error));

    clearInterval(sendTypingInterval);

    if(!response){
        message.reply("bwomp");
        return;
    }

    message.reply(response.choices[0].message.content);


});

client.login(process.env.TOKEN);

